import React, { useState, useEffect, useRef } from "react";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";

const COMPANY = {
  name: "AGL Ar Condicionado",
  site: "www.aglarcondicionado.com.br",
  phone: "(11) 91020-7001",
  insta: "@aglservicossp",
};

const LS_USERS = "agl_users_v2";
const LS_SESSION = "agl_session_v2";
const LS_DATA = "agl_data_v2";

const DEFAULT_USER = { username: "admin", password: "12345", name: "Administrador AGL" };

function loadLS(k, fallback){ try{ const r = localStorage.getItem(k); return r? JSON.parse(r): fallback }catch(e){return fallback} }
function saveLS(k,v){ localStorage.setItem(k, JSON.stringify(v)) }

// init
(function(){
  if(!loadLS(LS_USERS,null)) saveLS(LS_USERS,[DEFAULT_USER]);
  if(!loadLS(LS_DATA,null)) saveLS(LS_DATA,{orders:[],clients:[],techs:[],proposals:[],pmoc:[]});
})();

export default function App(){
  const [session, setSession] = useState(()=> loadLS(LS_SESSION,null));
  const [data, setData] = useState(()=> loadLS(LS_DATA,{orders:[],clients:[],techs:[],proposals:[],pmoc:[]}));
  const [view, setView] = useState("dashboard");
  const [query, setQuery] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const logoRef = useRef(null);

  useEffect(()=> saveLS(LS_DATA,data),[data]);
  useEffect(()=> saveLS(LS_SESSION,session),[session]);

  function login(username,password){
    const users = loadLS(LS_USERS,[]);
    const found = users.find(u=>u.username===username && u.password===password);
    if(!found){ alert("Credenciais inválidas"); return false; }
    setSession({ username:found.username, name: found.name });
    return true;
  }
  function logout(){ if(confirm("Encerrar sessão?")) setSession(null); }

  function newOrder(){ setEditing(null); setModalOpen(true); }

  function saveOrder(o){
    const payload = {...o, id: o.id || Math.random().toString(36).slice(2,9), updatedAt: new Date().toISOString() };
    setData(prev=> ({...prev, orders: [payload, ...prev.orders.filter(x=>x.id!==payload.id)] }));
    setModalOpen(false);
  }

  function exportOrderPDF(order, signatureDataUrl){
    // Build printable HTML with logo (public/logo-agl.png) and signature image embedded
    const logoSrc = "/logo-agl.png";
    const sigImg = signatureDataUrl ? `<div style="margin-top:12px;"><strong>Assinatura:</strong><br/><img src="${signatureDataUrl}" style="max-width:320px;border:1px solid #ddd"/></div>` : "";
    const html = `
      <div style="font-family:Arial,Helvetica,sans-serif;color:#111">
        <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #eee;padding-bottom:12px">
          <div><img src="${logoSrc}" style="height:60px"/></div>
          <div style="text-align:right"><strong>Ordem de Serviço</strong><br/>ID: ${order.id}</div>
        </div>
        <div style="margin-top:12px">
          <table style="width:100%;border-collapse:collapse">
            <tr><th style="text-align:left;padding:6px;border:1px solid #eee">Cliente</th><td style="padding:6px;border:1px solid #eee">${order.clientName||''}</td></tr>
            <tr><th style="text-align:left;padding:6px;border:1px solid #eee">Contato</th><td style="padding:6px;border:1px solid #eee">${order.clientPhone||''}</td></tr>
            <tr><th style="text-align:left;padding:6px;border:1px solid #eee">Equipamento</th><td style="padding:6px;border:1px solid #eee">${order.equipmentBrand||''} ${order.equipmentModel||''} ${order.equipmentBtu||''}</td></tr>
            <tr><th style="text-align:left;padding:6px;border:1px solid #eee">Itens</th><td style="padding:6px;border:1px solid #eee">${(order.items||[]).join(', ')}</td></tr>
            <tr><th style="text-align:left;padding:6px;border:1px solid #eee">Status</th><td style="padding:6px;border:1px solid #eee">${order.status||''}</td></tr>
          </table>
        </div>
        ${sigImg}
        <div style="margin-top:18px;color:#666;font-size:12px">Gerado por ${COMPANY.name} - ${new Date().toLocaleString()}</div>
      </div>
    `;
    // open printable window and trigger print (user can save as PDF)
    const w = window.open("", "_blank");
    if(!w){ alert("Permita pop-ups para imprimir/exportar"); return; }
    w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>Ordem ${order.id}</title></head><body>${html}</body></html>`);
    w.document.close();
    // optionally trigger print automatically after short delay
    setTimeout(()=>{ w.print(); }, 500);
  }

  if(!session) return <Login onLogin={login} />;

  const orders = data.orders.filter(o=>{
    if(!query) return true;
    const q = query.toLowerCase();
    return (o.clientName||'').toLowerCase().includes(q) || (o.id||'').toLowerCase().includes(q) || (o.status||'').toLowerCase().includes(q);
  });

  return (
    <div>
      <div className="header">
        <div className="brand">
          <img src="/logo-agl.png" alt="AGL" ref={logoRef} />
          <div style={{fontSize:18,fontWeight:700}}>{COMPANY.name}</div>
        </div>
        <div style={{display:'flex',alignItems:'center',gap:12}}>
          <div style={{textAlign:'right'}}><div style={{fontSize:12}}>{session.name}</div><div style={{fontSize:12,color:'#cbd5e1'}}>{COMPANY.phone}</div></div>
          <button className="btn gray" onClick={logout}>Sair</button>
        </div>
      </div>

      <div className="container">
        <div className="card">
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:12}}>
            <div><h3>Ordens de Serviço</h3><div style={{color:'#6b7280'}}>Gerencie ordens — instalar, manutenção, limpeza, reparos</div></div>
            <div style={{display:'flex',gap:8}}>
              <input placeholder="Pesquisar por cliente/ID/status" value={query} onChange={e=>setQuery(e.target.value)} className="input" />
              <button className="btn green" onClick={()=>{ setEditing(null); setModalOpen(true); }}>Nova Ordem</button>
            </div>
          </div>

          <table className="table">
            <thead><tr><th>ID</th><th>Cliente</th><th>Equip.</th><th>Téc.</th><th>Status</th><th>Ações</th></tr></thead>
            <tbody>
              {orders.length===0 && <tr><td colSpan={6} style={{padding:20,textAlign:'center',color:'#6b7280'}}>Nenhuma ordem</td></tr>}
              {orders.map(o=>(
                <tr key={o.id}>
                  <td>{o.id}</td>
                  <td>{o.clientName}</td>
                  <td>{o.equipmentBrand} {o.equipmentBtu}</td>
                  <td>{o.techName||'--'}</td>
                  <td>{o.status}</td>
                  <td style={{display:'flex',gap:8}}>
                    <button className="btn" onClick={()=>{ setEditing(o); setModalOpen(true); }}>Editar</button>
                    <button className="btn" onClick={()=>exportOrderPDF(o, null)}>Exportar PDF</button>
                    <button className="btn" onClick={()=>{ const txt=`Ordem AGL - ${o.id}%0ACliente: ${o.clientName}`; window.open(`https://wa.me/?text=${encodeURIComponent(txt)}`,'_blank') }}>Whats</button>
                    <button className="btn" onClick={()=>{ window.location.href=`mailto:${o.clientEmail||''}?subject=Ordem%20${o.id}&body=Ordem%20${o.id}` }}>Email</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div style={{height:16}} />

        <div className="card">
          <h4>Relatórios Rápidos</h4>
          <div style={{display:'flex',gap:8,marginTop:8}}>
            <div className="card" style={{padding:12}}><strong>{data.orders.length}</strong><div style={{fontSize:12,color:'#6b7280'}}>Total Ordens</div></div>
            <div className="card" style={{padding:12}}><strong>{data.orders.filter(x=>x.status==='Em andamento').length}</strong><div style={{fontSize:12,color:'#6b7280'}}>Em andamento</div></div>
            <div className="card" style={{padding:12}}><strong>{data.orders.filter(x=>x.status==='Pendente').length}</strong><div style={{fontSize:12,color:'#6b7280'}}>Pendentes</div></div>
          </div>
        </div>
      </div>

      {modalOpen && <OrderModal initial={editing} onClose={()=>setModalOpen(false)} onSave={(o,signature)=>{ saveOrder(o); /* save signature in order for later export */ if(signature){ setData(prev=>{ const updated = prev.orders.map(x=> x.id===o.id? {...o, signature}: x); if(!updated.find(x=>x.id===o.id)) updated = [ {...o, signature}, ...updated ]; return {...prev, orders: updated }; }); } }} />}
    </div>
  );
}

/* Login */
function Login({ onLogin }) {
  const [u, setU] = useState("admin");
  const [p, setP] = useState("12345");
  return (
    <div style={{minHeight:'100vh',display:'flex',alignItems:'center',justifyContent:'center',background:'#f3f4f6'}}>
      <div className="card" style={{maxWidth:420,width:'100%'}}>
        <h2>AGL SaaS - Login</h2>
        <div style={{marginTop:8}}><label>Usuário</label><input value={u} onChange={e=>setU(e.target.value)} className="input" /></div>
        <div style={{marginTop:8}}><label>Senha</label><input type="password" value={p} onChange={e=>setP(e.target.value)} className="input" /></div>
        <div style={{marginTop:12,display:'flex',gap:8}}>
          <button className="btn blue" onClick={()=>onLogin(u,p)}>Entrar</button>
          <button className="btn gray" onClick={()=>{ localStorage.setItem(LS_USERS, JSON.stringify([DEFAULT_USER])); alert('Demo restaurado'); }}>Restaurar demo</button>
        </div>
      </div>
    </div>
  );
}

/* Modal with order form and signature canvas */
function OrderModal({ initial={}, onClose, onSave }){
  const [s, setS] = useState({...initial});
  const canvasRef = useRef(null);
  const drawing = useRef(false);

  useEffect(()=>{
    // prepare canvas if signature exists
    if(initial && initial.signature && canvasRef.current){
      const ctx = canvasRef.current.getContext('2d');
      const img = new Image();
      img.onload = ()=>{ ctx.clearRect(0,0,canvasRef.current.width,canvasRef.current.height); ctx.drawImage(img,0,0,canvasRef.current.width,canvasRef.current.height); }
      img.src = initial.signature;
    }
  },[initial]);

  useEffect(()=>{
    const c = canvasRef.current;
    if(!c) return;
    const ctx = c.getContext('2d');
    const dpr = window.devicePixelRatio || 1;
    const rect = c.getBoundingClientRect();
    c.width = rect.width * dpr;
    c.height = rect.height * dpr;
    ctx.scale(dpr,dpr);
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#111';
  },[]);

  function getPos(e){
    const rect = canvasRef.current.getBoundingClientRect();
    if(e.touches) { const t = e.touches[0]; return {x: t.clientX - rect.left, y: t.clientY - rect.top}; }
    return {x: e.clientX - rect.left, y: e.clientY - rect.top};
  }
  function startDraw(e){ drawing.current = true; const p = getPos(e); const ctx = canvasRef.current.getContext('2d'); ctx.beginPath(); ctx.moveTo(p.x,p.y); e.preventDefault(); }
  function moveDraw(e){ if(!drawing.current) return; const p = getPos(e); const ctx = canvasRef.current.getContext('2d'); ctx.lineTo(p.x,p.y); ctx.stroke(); e.preventDefault(); }
  function endDraw(e){ drawing.current = false; e.preventDefault(); }

  function clearSig(){ const ctx = canvasRef.current.getContext('2d'); ctx.clearRect(0,0,canvasRef.current.width,canvasRef.current.height); }

  function submit(e){
    e.preventDefault();
    // extract signature
    let sig = null;
    if(canvasRef.current){
      sig = canvasRef.current.toDataURL('image/png');
    }
    const payload = {...s, id: s.id || Math.random().toString(36).slice(2,9)};
    onSave(payload, sig);
    onClose();
  }

  return (
    <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.4)',display:'flex',alignItems:'start',justifyContent:'center',padding:20,zIndex:60}}>
      <div style={{width:'100%',maxWidth:900,background:'white',borderRadius:8,padding:16}}>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}><h3>Ordem de Serviço</h3><div><button className="btn" onClick={onClose}>Fechar</button></div></div>
        <form onSubmit={submit} style={{display:'grid',gridTemplateColumns:'1fr 320px',gap:12,marginTop:12}}>
          <div>
            <div className="form-row"><label>Cliente</label><input className="input" value={s.clientName||''} onChange={e=>setS({...s, clientName: e.target.value})} /></div>
            <div className="form-row"><label>CPF / CNPJ</label><input className="input" value={s.clientCpfCnpj||''} onChange={e=>setS({...s, clientCpfCnpj: e.target.value})} /></div>
            <div className="form-row"><label>Telefone</label><input className="input" value={s.clientPhone||''} onChange={e=>setS({...s, clientPhone: e.target.value})} /></div>
            <div className="form-row"><label>Marca</label><input className="input" value={s.equipmentBrand||''} onChange={e=>setS({...s, equipmentBrand: e.target.value})} /></div>
            <div className="form-row"><label>Modelo</label><input className="input" value={s.equipmentModel||''} onChange={e=>setS({...s, equipmentModel: e.target.value})} /></div>
            <div className="form-row"><label>BTUs</label><input className="input" value={s.equipmentBtu||''} onChange={e=>setS({...s, equipmentBtu: e.target.value})} /></div>
            <div className="form-row"><label>Itens (separe por vírgula)</label><input className="input" value={(s.items||[]).join(', ')} onChange={e=>setS({...s, items: e.target.value.split(',').map(x=>x.trim())})} /></div>
            <div style={{marginTop:8}}><label>Status</label><select className="input" value={s.status||'Pendente'} onChange={e=>setS({...s, status: e.target.value})}><option>Pendente</option><option>Em andamento</option><option>Concluído</option></select></div>
            <div style={{marginTop:12,display:'flex',gap:8}}><button className="btn blue" type="submit">Salvar Ordem + Assinatura</button><button type="button" className="btn gray" onClick={()=>{ /* export with signature */ const sig = canvasRef.current? canvasRef.current.toDataURL(): null; const payload = {...s, id: s.id || Math.random().toString(36).slice(2,9)}; // open PDF preview with signature
              const w = window.open('about:blank','_blank'); const logo='/logo-agl.png'; const sigHtml = sig? `<div style=\"margin-top:12px\"><strong>Assinatura:</strong><br/><img src=\"${sig}\" style=\"max-width:320px;border:1px solid #ddd\"/></div>`:''; const html = `<div style=\"font-family:Arial;padding:20px\"><div style=\"display:flex;justify-content:space-between\"><img src=\"${logo}\" style=\"height:60px\"/><div><strong>Ordem</strong><br/>ID:${payload.id}</div></div><div style=\"margin-top:12px\"><table style=\"width:100%;border-collapse:collapse\"><tr><th style=\"text-align:left;padding:6px;border:1px solid #eee\">Cliente</th><td style=\"padding:6px;border:1px solid #eee\">${payload.clientName||''}</td></tr></table>${sigHtml}</div></div>`; w.document.write(html); w.document.close(); setTimeout(()=>w.print(),400); }}>Exportar (com assinatura)</button></div>
          </div>
          <div>
            <div className="card"><label>Assinatura do Cliente</label>
              <div style={{marginTop:8}}>
                <canvas className="signature-canvas" ref={canvasRef} onMouseDown={startDraw} onMouseMove={moveDraw} onMouseUp={endDraw} onMouseLeave={endDraw}
                  onTouchStart={startDraw} onTouchMove={moveDraw} onTouchEnd={endDraw}></canvas>
                <div style={{display:'flex',gap:8,marginTop:8}}><button type="button" className="btn gray" onClick={()=>{ const c=canvasRef.current; const ctx=c.getContext('2d'); ctx.clearRect(0,0,c.width,c.height); }}>Limpar</button></div>
              </div>
            </div>
            <div style={{marginTop:12}} className="card">
              <strong>Resumo</strong>
              <div style={{marginTop:8,fontSize:13,color:'#6b7280'}}>Ao salvar, a assinatura será incorporada na ordem e disponível para exportar em PDF.</div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );

  // canvas drawing helpers (inside modal to access canvasRef)
  function getPos(e){
    const rect = canvasRef.current.getBoundingClientRect();
    if(e.touches){ const t = e.touches[0]; return {x: t.clientX - rect.left, y: t.clientY - rect.top}; }
    return {x: e.clientX - rect.left, y: e.clientY - rect.top};
  }
  function startDraw(e){ drawingStart(e); }
  function moveDraw(e){ drawingMove(e); }
  function endDraw(e){ drawingEnd(e); }

  // simple drawing functions using closure-resident canvasRef
  function drawingStart(e){
    const c = canvasRef.current; if(!c) return;
    const ctx = c.getContext('2d');
    const rect = c.getBoundingClientRect(); const dpr = window.devicePixelRatio || 1;
    // ensure proper scaling
    if(c.width === 0){ c.width = rect.width * dpr; c.height = rect.height * dpr; ctx.scale(dpr,dpr); ctx.lineWidth = 2; ctx.lineCap = 'round'; ctx.strokeStyle = '#111'; }
    const p = getPos(e);
    ctx.beginPath(); ctx.moveTo(p.x,p.y);
    canvasRef.current._drawing = true;
    e.preventDefault();
  }
  function drawingMove(e){
    const c = canvasRef.current; if(!c || !c._drawing) return;
    const ctx = c.getContext('2d'); const p = getPos(e); ctx.lineTo(p.x,p.y); ctx.stroke(); e.preventDefault();
  }
  function drawingEnd(e){ if(canvasRef.current) canvasRef.current._drawing = false; e.preventDefault && e.preventDefault(); }
}