AGL SaaS - Demo (offline)
=========================

This is a lightweight React + Vite demo for AGL Ar Condicionado.
- Login: admin / 12345
- LocalStorage is used for data persistence.
- Public/logo-agl.png is included and used in exports.
- Export (PDF) opens a printable window; you can save as PDF from browser print dialog.
- Signature captured on canvas and embedded in exports.

To run:
1. npm install
2. npm run dev